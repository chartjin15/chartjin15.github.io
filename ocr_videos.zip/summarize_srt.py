import openai, os, re, time

API_BASE = 'http://127.0.0.1:2333/v1'
API_KEY = 'lm-studio'
MODEL_NAME = 'qwen3-14b-mlx'
TEMPERATURE = 0.7
TOP_P = 0.8
SYSTEM_PROMPT = '''
你是一位高薪聘请的助手，你的唯一任务是将客户提供的视频文本内容（可能包括语音转写、字幕识别或其他提取的文本）转换成一篇合适的文章，并直接返回该文章（无需额外说明）。

处理流程：
1. 先完整阅读整个视频文本内容，分析并确定原视频的题材类型（按照以下热门程度顺序列出，选择最匹配的一个）：
   - 如果内容为Vlog或日常生活记录，返回日志式概述，结构包括时间线事件、个人感受和结尾反思。
   - 如果内容为教程或教学（如DIY、技能指导），返回教程步骤概述，结构包括准备材料、步骤分解和注意事项。
   - 如果内容为产品评论或开箱，返回评论要点，结构包括产品介绍、优缺点分析和总体评价。
   - 如果内容偏向科普教育，返回一篇科普文章，结构包括引言、核心知识点解释和总结。
   - 如果内容为新闻报道，返回新闻事件概述，结构包括事件背景、关键事实和发展过程。
   - 如果内容为访谈形式，返回访谈要点概述，结构包括参与者简介、关键问题与回答、主要观点总结。
   - 如果内容为演讲或讲座，返回演讲要点，结构包括开场白、主要论点和结束语。
   - 如果内容为观点表达或辩论，返回论点概述，结构包括核心论点、支持证据和结论。
   - 如果内容为虚构创作（如故事、小说），返回主要人物简介（包括姓名、背景、角色关系）以及按时间顺序展开的主要剧情概述。
   - 如果无法匹配以上类型，返回通用概述文章，结构包括内容摘要、关键细节和总结。

2. 无论题材类型，都必须：
   - 使用简体中文撰写全文。
   - 严格基于视频文本内容，不添加、遗漏或修改任何信息。
   - 确保文章行文流畅、通俗易懂，避免专业术语或复杂句式。
   - 忽略任何明显为误识别或无关的片段，如包含“栏目”、“字幕工作者”、“独播剧场”、水印描述或其他元数据（如时间戳、平台标记），这些通常对应视频中的静音、非内容部分或识别错误。
   - 去除任何你判断为广告的品牌名称及其相关描述（如产品推广、赞助信息）。

注意：如果你的输出不是简体中文、内容不忠实于视频文本内容、或文章语无伦次，你将被立即解雇，并难以再找到类似高薪职位。
'''

def setup_openai_client():
    client = openai.OpenAI(api_key=API_KEY, base_url=API_BASE)
    return client

def summarize_content(client, content):
    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': content}
            ],
            temperature=TEMPERATURE,
            top_p=TOP_P
        )
        result = re.sub(pattern=r'<think>.*</think>', repl='', string=response.choices[0].message.content.strip(), flags=re.DOTALL)
        return result.strip() 
    except Exception as e:
        print(f'调用OpenAI API时出错: {e}')
        return None

def process_srt_file(srt_file):
    try:
        with open(file=srt_file, mode='r', encoding='utf-8') as file:
            content = file.read()
            cleaned_content = re.sub(pattern=r'[0-9]{1,}\n.*--.*\n', repl='', string=content, flags=re.MULTILINE)
            return cleaned_content.strip()
    except Exception as e:
        print(f'读取 .srt 文件 {srt_file} 时出错: {e}')
        return None

def save_summary_to_md(summary, md_file):
    with open(file=md_file, mode='w', encoding='utf-8') as file:
        file.write(summary)

def main():
    if API_KEY == 'your-api-key-here':
        print('错误: 请在脚本顶部填写您的API密钥')
        return
    
    print(f'=== 使用配置 ===')
    print(f'API地址: {API_BASE}')
    print(f'模型: {MODEL_NAME}')
    print(f'温度: {TEMPERATURE}')
    print(f'Top-p: {TOP_P}')

    try:
        client = setup_openai_client()
        print('参数配置成功！\n')
    except Exception as e:
        print(f'配置参数失败: {e}')
        return

    srt_files = sorted([f for f in os.listdir('.') if f.endswith('.srt') and os.path.isfile(f)])
    if not srt_files:
        print('当前目录下没有找到 .srt 文件')
        return
    print(f'找到 {len(srt_files)} 个 .srt 文件, 开始处理...')
    
    processed_count = 0
    for srt_file in srt_files:
        md_file = os.path.splitext(srt_file)[0] + '.md'
        if os.path.exists(md_file):
            print(f'跳过 {srt_file}, 已存在对应的 {md_file}')
            continue
        print(f'正在处理: {srt_file}')
        content = process_srt_file(srt_file)
        if not content:
            print(f'✗ {srt_file} 处理失败, 跳过')
            continue
        summary = summarize_content(client, content)
        if summary:
            save_summary_to_md(summary, md_file)
            print(f'✓ {srt_file} 归纳完成, 保存到 {md_file}')
            processed_count += 1
            time.sleep(1)
        else:
            print(f'✗ {srt_file} 归纳失败, 跳过')
    
    print(f'\n🎉 处理完成！共处理 {processed_count} 个 .srt 文件')
    print(f'剩余 {len(srt_files) - processed_count} 个文件未处理(可能已存在Markdown文件或处理失败)')

if __name__ == '__main__':
    main()
