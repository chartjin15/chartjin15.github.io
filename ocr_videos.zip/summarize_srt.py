import openai, os, re, time

API_BASE = 'http://127.0.0.1:2333/v1'
API_KEY = 'lm-studio'
MODEL_NAME = 'qwen3-14b-mlx'
TEMPERATURE = 0.7
TOP_P = 0.8
SYSTEM_PROMPT = '你是一位被高薪聘请的助手, 你需要将客户提供的语音转写转换成一篇文章。你仅需用简体中文返回严格遵循语音转写内容的文章, 并确保行文流畅、通俗易懂。注意: 使用非简体中文回答或语无伦次会使你被解雇并很难再找到这么高薪水的工作。'

def setup_openai_client():
    client = openai.OpenAI(api_key=API_KEY, base_url=API_BASE)
    return client

def summarize_content(client, content):
    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': content}
            ],
            temperature=TEMPERATURE,
            top_p=TOP_P
        )
        result = re.sub(pattern=r'<think>.*</think>', repl='', string=response.choices[0].message.content.strip(), flags=re.DOTALL)
        return result.strip() 
    except Exception as e:
        print(f'调用OpenAI API时出错: {e}')
        return None

def process_srt_file(srt_file):
    try:
        with open(file=srt_file, mode='r', encoding='utf-8') as file:
            content = file.read()
            cleaned_content = re.sub(pattern=r'[0-9]{1,}\n.*--.*\n', repl='', string=content, flags=re.MULTILINE)
            return cleaned_content.strip()
    except Exception as e:
        print(f'读取 .srt 文件 {srt_file} 时出错: {e}')
        return None

def save_summary_to_md(summary, md_file):
    with open(file=md_file, mode='w', encoding='utf-8') as file:
        file.write(summary)

def main():
    if API_KEY == 'your-api-key-here':
        print('错误: 请在脚本顶部填写您的API密钥')
        return
    
    print(f'=== 使用配置 ===')
    print(f'API地址: {API_BASE}')
    print(f'模型: {MODEL_NAME}')
    print(f'温度: {TEMPERATURE}')
    print(f'Top-p: {TOP_P}')

    try:
        client = setup_openai_client()
        print('参数配置成功！\n')
    except Exception as e:
        print(f'配置参数失败: {e}')
        return

    srt_files = sorted([f for f in os.listdir('.') if f.endswith('.srt') and os.path.isfile(f)])
    if not srt_files:
        print('当前目录下没有找到 .srt 文件')
        return
    print(f'找到 {len(srt_files)} 个 .srt 文件, 开始处理...')
    
    processed_count = 0
    for srt_file in srt_files:
        md_file = os.path.splitext(srt_file)[0] + '.md'
        if os.path.exists(md_file):
            print(f'跳过 {srt_file}, 已存在对应的 {md_file}')
            continue
        print(f'正在处理: {srt_file}')
        content = process_srt_file(srt_file)
        if not content:
            print(f'✗ {srt_file} 处理失败, 跳过')
            continue
        summary = summarize_content(client, content)
        if summary:
            save_summary_to_md(summary, md_file)
            print(f'✓ {srt_file} 归纳完成, 保存到 {md_file}')
            processed_count += 1
            time.sleep(1)
        else:
            print(f'✗ {srt_file} 归纳失败, 跳过')
    
    print(f'\n🎉 处理完成！共处理 {processed_count} 个 .srt 文件')
    print(f'剩余 {len(srt_files) - processed_count} 个文件未处理(可能已存在Markdown文件或处理失败)')

if __name__ == '__main__':
    main()
