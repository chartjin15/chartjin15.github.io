## 事先准备

- 下载`yt-dlp`可执行文件并将其移动到: [Linux](https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp)或[macOS](https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos)
- 安装OpenAI的Python库: `pip install openai`
    - 如果下载包失败, 请切换PyPI源: `pip config set global.index-url https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple`
- (可选) 安装OpenCV视觉库的Python版: `pip install opencv-python`
- (可选) 安装`requests`或`pyobjc`库: `pip install requests`或`pip install pyobjc`
- (推荐) 安装`ffmpeg`和`aria2c`: `sudo apt install ffmpeg aria2`或`brew install ffmpeg aria2`

## 文件说明

1. `quick_download.sh`: 快速下载视频轨或音频轨的`Bash`脚本, 在`macOS`中需要将`yt-dlp`替换为`yt-dlp_macos`
2. `ocr_videos_*.py`: 使用`pyobjc`库(存在严重内存泄漏)调用`Apple`的`Vision`库或图像文本识别接口识别视频中的文本
3. `similarity_remove*.py`: 简单的去除重复行工具
4. `split_by_length.py`: 简单的内容分割工具, 仅用于故事文本归纳
5. `summarize_*.py`: 简单的内容归纳工具, 用于通用目的
6. `summarize_story.py`: 简单的故事归纳工具, 仅用于故事文本归纳

## 视频识别

- 识别通用视频请按照下面步骤执行相关文件: `quick_download.sh -> ocr_videos_*.py -> similarity_remove.py -> summarize_refined.py`, 并在使用阅读所有`.md`文件后适时删除`.mp4`、`.txt`和`.refined`文件
- 识别故事视频请按照下面步骤执行相关文件: `quick_download.sh -> ocr_videos_*.py -> similarity_remove.py -> split_by_length.py -> summarize_story.py`, 并在使用阅读`.md`文件后适时删除`.mp4`、`.txt`、`.story`和`.json`文件

## 音频识别

- 推荐使用`Google Colab`、`SageMaker Studio Lab`等在线工具进行音频转录, 省去任何配置CUDA等的麻烦
- 进行音频识别前, 需要先安装: `pip install whisper-ctranslate2`, 其基于`Faster Whisper`实现
    - 不使用如`WhisperX`这样拥有更好语音活动检测实现的工具是因为其与`Google Colab`环境不兼容, 且不支持`mlx`框架
    - 不使用如`mlx-whisper`是因为其长语音识别能力堪忧, 经常性生成重复无意义内容
    - 不使用如`pyVideoTrans`是因为其说明文档写得太糟糕了
- 在使用了`yt-dlp`获得了音频文件后, 运行类似以下的命令即可转录所有的音频: `for file in *.m4a; do whisper-ctranslate2 "$file" --language zh --initial_prompt "注意看 这是一段中文普通话" --device cuda --output_format srt --model_directory /content/drive/MyDrive/model --local_files_only True --verbose False; done`
- 可以自行选择模型, 建议使用以下模型: [mobiuslabsgmbh/faster-whisper-large-v3-turbo](https://huggingface.co/mobiuslabsgmbh/faster-whisper-large-v3-turbo)

## 图像识别

- 图片识别更加简单, 只需运行类似以下的命令: `for file in *.png; do curl -s -H "Accept: application/json" -X POST http://192.168.0.55:8000/upload -F "file=@$file" | jq -r '.ocr_result' > "${file%.png}.txt"; done`
- 对于由`macOS`中`Shortcuts`指令由PDF生成的图片, 若想要将所有图片识别结果合并为一个文档可以运行下面的命令: `printf '%s\0' *.txt | LC_COLLATE=C sort -z -V | xargs -0 cat -- > merged.txt`
