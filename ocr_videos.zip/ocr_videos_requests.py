# 使用https://github.com/riddleling/iOS-OCR-Server进行图像识别
import cv2
import os
import requests
import sys
import time

def ocr_with_api(image_data, api_url='http://192.168.0.55:8000/upload'):
    try:
        files = {'file': ('image.png', image_data, 'image/png')}
        headers = {'Accept': 'application/json'}
        response = requests.post(api_url, files=files, headers=headers)

        if response.status_code == 200:
            result = response.json()
            if result.get('success', False):
                return result.get('ocr_result', '').split('\n')
            else:
                print(f'OCR API返回错误: {result.get("message", "未知错误")}')
                return []
        else:
            print(f'OCR请求失败，状态码: {response.status_code}, 响应: {response.text}')
            return []
    except Exception as e:
        print(f'OCR请求异常: {str(e)}')
        return []

def process_video_ocr(video_path, interval=3, crop_region=(0, 0, 1920, 1080), api_url='http://192.168.0.55:8000/upload'):
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    output_txt = f'{video_name}.txt'
    if os.path.exists(output_txt):
        print(f'跳过 {video_path}，因为 {output_txt} 已存在')
        return

    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_interval = int(fps * interval)

    x, y, w, h = crop_region
    ocr_results = []
    frame_count = 0

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if cap.get(cv2.CAP_PROP_FRAME_COUNT) > 0 else None
    start_time = time.time()
    bar_len = 20

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        if frame_count % frame_interval == 0:
            sys.stdout.write('\r')
            sys.stdout.flush()

            if y + h <= frame.shape[0] and x + w <= frame.shape[1]:
                cropped_frame = frame[y:y+h, x:x+w]
                img_rgb = cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2RGB)
                _, img_encoded = cv2.imencode('.png', img_rgb)
                img_data = img_encoded.tobytes()

                frame_ocr_result = ocr_with_api(img_data, api_url)

                if frame_ocr_result:
                    timestamp = frame_count / fps
                    ocr_results.append(f'{timestamp:.2f},{",".join(frame_ocr_result)}')
            else:
                print(f'警告: {video_path} 裁剪区域 ({x}, {y}, {w}, {h}) 超出帧尺寸 {frame.shape}')

            if total_frames:
                percent = frame_count / total_frames
                filled = int(bar_len * percent) + 1
                bar = '[' + '#' * filled + '-' * (bar_len - filled) + ']'
                elapsed = int(time.time() - start_time)
                sys.stdout.write(f'\r\t进度: {bar} {frame_count}/{total_frames} ({percent:.1%}) 用时: {elapsed}s')
            else:
                sys.stdout.write(f'\r\t进度: 处理到帧 {frame_count}')
            sys.stdout.flush()

        frame_count += 1

    cap.release()
    print()

    if ocr_results:
        with open(output_txt, 'w', encoding='utf-8') as f:
            for result in ocr_results:
                f.write(result + '\n')
        print(f'完成！{video_path} 的OCR结果已保存至 {output_txt}')
    else:
        print(f'{video_path} 无OCR结果，未生成 {output_txt}')

if __name__ == '__main__':
    mp4_files = sorted([f for f in os.listdir('.') if f.endswith('.mp4') and os.path.isfile(f)])
    if not mp4_files:
        print('当前目录下未找到任何 .mp4 文件')
    else:
        print(f'找到 {len(mp4_files)} 个 .mp4 文件')
        for video_path in mp4_files:
            print(f'处理视频: {video_path}')
            process_video_ocr(video_path, interval=3, crop_region=(0, 0, 1920, 1080))
