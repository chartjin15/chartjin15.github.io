import json, openai, os, re, time

API_BASE = 'http://127.0.0.1:2333/v1'
API_KEY = 'lm-studio'
MODEL_NAME = 'qwen3-14b-mlx'
TEMPERATURE = 0.7
TOP_P = 0.8
SYSTEM_PROMPT = '你是一位被高薪聘请的助手, 你需要将客户提供的OCR识别得到的故事对话段落改写为“人物: 发言”格式故事剧本。你仅需用简体中文返回不遗漏情节并不脱离原意的故事剧本, 每行前后高频存在的文本可能是误识别到的水印等需要忽略。注意: 使用非简体中文回答或语无伦次会使你被解雇并很难再找到这么高薪水的工作。'
# SYSTEM_PROMPT = '你是一位被高薪聘请的助手, 目前正在帮助客户归纳他提供的OCR识别得到的故事对话。在归纳时, 你需要准确列出文本中出场的主要角色及简单介绍, 并按照时间顺序列出主要发生的剧情。你仅需用简体中文返回归纳部分的内容, 使用非简体中文回答或语无伦次会使你被解雇并很难再找到这么高薪水的工作。'

def setup_openai_client():
    client = openai.OpenAI(api_key=API_KEY, base_url=API_BASE)
    return client

def summarize_content(client, content):
    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': content}
            ],
            temperature=TEMPERATURE,
            top_p=TOP_P
        )
        result = re.sub(pattern=r'<think>.*</think>', repl='', string=response.choices[0].message.content.strip(), flags=re.DOTALL)
        return result.strip() 
    except Exception as e:
        print(f'调用OpenAI API时出错: {e}')
        return None

def load_chapters_from_json(json_file):
    try:
        with open(file=json_file, mode='r', encoding='utf-8') as file:
            return json.load(fp=file)
    except FileNotFoundError:
        print(f'错误: 找不到文件 {json_file}')
        return []
    except json.JSONDecodeError:
        print(f'错误: {json_file} 不是有效的JSON文件')
        return []

def save_chapters_to_json(chapters, json_file):
    with open(file=json_file, mode='w', encoding='utf-8') as file:
        json.dump(obj=chapters, fp=file, ensure_ascii=False)

def append_to_summary_file(chapter_title, summary, summary_file):
    with open(file=summary_file, mode='a', encoding='utf-8') as file:
        file.write(f'## {chapter_title}\n\n')
        file.write(f'{summary}\n\n')

def process_summarize(json_file):
    summary_file = f'{os.path.splitext(os.path.basename(json_file))[0]}.md'
    
    if API_KEY == 'your-api-key-here':
        print('错误: 请在脚本顶部填写您的API密钥')
        return

    print(f'=== 使用配置 ===')
    print(f'API地址: {API_BASE}')
    print(f'模型: {MODEL_NAME}')
    print(f'温度: {TEMPERATURE}')
    print(f'Top-p: {TOP_P}')

    try:
        client = setup_openai_client()
        print('参数配置成功!\n')
    except Exception as e:
        print(f'配置参数失败: {e}')
        return

    chapters = load_chapters_from_json(json_file)
    if not chapters:
        print('没有找到章节数据, 请先运行文本分割脚本')
        return

    print(f'找到 {len(chapters)} 个章节, 开始归纳...')

    processed_count = 0
    while chapters:
        chapter = chapters[0]
        chapter_title = chapter['chapter']
        content = chapter['content']

        print(f'正在处理: {chapter_title}')
        summary = summarize_content(client, content)
        
        if summary:
            append_to_summary_file(chapter_title, summary, summary_file)
            print(f'✓ {chapter_title} 归纳完成')
            chapters.pop(0)
            save_chapters_to_json(chapters, json_file)
            processed_count += 1
            time.sleep(1)
        else:
            print(f'✗ {chapter_title} 归纳失败, 程序将退出')
            break

    if not chapters:
        print(f'\n🎉 所有章节归纳完成! 共处理 {processed_count} 个章节')
        print(f'总结已保存到: {summary_file}')
    else:
        print(f'\n⚠️ 处理中断, 已完成 {processed_count} 个章节的归纳')
        print(f'剩余 {len(chapters)} 个章节可稍后继续处理')

if __name__ == '__main__':
    json_files = sorted([f for f in os.listdir('.') if f.endswith('.json') and os.path.isfile(f)])
    if not json_files:
        print('当前目录下未找到任何 .json 文件')
    else:
        print(f'找到 {len(json_files)} 个 .json 文件')
        for json_file in json_files:
            process_summarize(json_file=json_file)
