import cv2
import os
import requests
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

def ocr_with_api(image_data, api_url='http://192.168.0.55:8000/upload'):
    try:
        files = {'file': ('image.png', image_data, 'image/png')}
        headers = {'Accept': 'application/json'}
        response = requests.post(api_url, files=files, headers=headers, timeout=30)

        if response.status_code == 200:
            result = response.json()
            if result.get('success', False):
                return result.get('ocr_result', '').split('\n')
            else:
                print(f'OCR API返回错误: {result.get("message", "未知错误")}')
                return []
        else:
            print(f'OCR请求失败，状态码: {response.status_code}, 响应: {response.text}')
            return []
    except Exception as e:
        print(f'OCR请求异常: {str(e)}')
        return []

def process_video_ocr(video_path, interval=3, crop_region=(0, 0, 1920, 1080), api_url='http://192.168.0.55:8000/upload'):
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    output_txt = f'{video_name}.txt'
    if os.path.exists(output_txt):
        print(f'跳过 {video_path}，因为 {output_txt} 已存在')
        return video_path, False

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f'无法打开视频文件: {video_path}')
        return video_path, False

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_interval = max(1, int(fps * interval))

    ocr_results = []
    frame_count = 0
    start_time = time.time()

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        if frame_count % frame_interval == 0:
            img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            _, img_encoded = cv2.imencode('.png', img_rgb)
            img_data = img_encoded.tobytes()

            frame_ocr_result = ocr_with_api(img_data, api_url)

            if frame_ocr_result:
                timestamp = frame_count / fps
                ocr_results.append(f'{timestamp:.2f},{",".join(frame_ocr_result)}')

        frame_count += 1

    cap.release()

    if ocr_results:
        with open(output_txt, 'w', encoding='utf-8') as f:
            for result in ocr_results:
                f.write(result + '\n')
        elapsed = int(time.time() - start_time)
        print(f'{video_path} 完成! 用时: {elapsed}s, OCR结果已保存至 {output_txt}')
        return video_path, True
    else:
        print(f'{video_path} 无OCR结果，未生成 {output_txt}')
        return video_path, False

def run_parallel_on_videos(video_list, max_workers=16, interval=3, crop_region=(0, 0, 1920, 1080), api_url='http://192.168.0.55:8000/upload'):
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as exe:
        futures = {exe.submit(process_video_ocr, video, interval, crop_region, api_url): video for video in video_list}
        for future in as_completed(futures):
            try:
                res = future.result()
                results.append(res)
            except Exception as e:
                print(f'任务异常: {str(e)}')
    return results

if __name__ == '__main__':
    mp4_files = sorted([f for f in os.listdir('.') if f.endswith('.mp4') and os.path.isfile(f)])
    if not mp4_files:
        print('当前目录下未找到任何 .mp4 文件')
    else:
        print(f'找到 {len(mp4_files)} 个 .mp4 文件')
        MAX_WORKERS = min(4, len(mp4_files))
        results = run_parallel_on_videos(mp4_files, max_workers=MAX_WORKERS, interval=3, crop_region=(0, 0, 1920, 1080))

        succeeded = sum(1 for _, ok in results if ok)
        print(f'完成! 为 {succeeded}/{len(results)} 个视频生成了 OCR 结果')
