import openai
import os
import re
import time


# ===== 用户配置区域 =====
# 请在这里填写您的配置信息
API_BASE = 'http://127.0.0.1:2333/v1'  # OpenAI兼容接口地址
API_KEY = 'lm-studio'  # 您的API密钥
MODEL_NAME = 'qwen3-30b-a3b-instruct-2507-mlx'  # 模型名称
TEMPERATURE = 0.7  # 温度值 (0.0-2.0)
TOP_P = 0.8  # top_p值 (0.0-1.0)
SYSTEM_PROMPT = '你是一位被高薪聘请的助手，目前正在帮助客户归纳他提供的OCR识别得到的故事对话。在归纳时，你需要准确列出文本中出场的主要角色及简单介绍，并按照时间顺序列出主要发生的剧情。你仅需用简体中文返回归纳部分的内容，使用非简体中文回答或语无伦次会使你被解雇并很难再找到这么高薪水的工作。'
# =======================


def setup_openai_client():
    '''
    配置OpenAI客户端

    Returns:
        openai.OpenAI: 配置好的OpenAI客户端
    '''
    client = openai.OpenAI(
        api_key=API_KEY,
        base_url=API_BASE
    )
    return client


def summarize_content(client, content):
    '''
    使用OpenAI模型归纳内容
    
    Args:
        client: OpenAI客户端
        content (str): 要归纳的内容
        
    Returns:
        str: 归纳后的内容
    '''
    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': f'{content}'}
            ],
            temperature=TEMPERATURE,
            top_p=TOP_P
        )
        
        result = response.choices[0].message.content.strip()
        
        # 去除<think></think>标签及其内容
        result = re.sub(r'<think>.*</think>', '', result, flags=re.DOTALL)
        
        return result.strip()
        
    except Exception as e:
        print(f'调用OpenAI API时出错：{e}')
        return None


def process_refined_file(refined_file):
    '''
    读取REFINED文件并清理内容
    
    Args:
        refined_file (str): REFINED文件路径
        
    Returns:
        str: 清理后的内容
    '''
    try:
        with open(refined_file, 'r', encoding='utf-8') as file:
            content = file.read()
            # 去除字幕编号和时间戳（[0-9]{1,}\n.*--.*\n）
            cleaned_content = re.sub(r'[0-9]{1,}\n.*--.*\n', '', content, flags=re.MULTILINE)
            return cleaned_content.strip()
    except Exception as e:
        print(f'读取REFINED文件 {refined_file} 时出错：{e}')
        return None


def save_summary_to_md(summary, md_file):
    '''
    将归纳内容保存到Markdown文件
    
    Args:
        summary (str): 归纳内容
        md_file (str): Markdown文件路径
    '''
    with open(md_file, 'w', encoding='utf-8') as file:
        file.write(summary)


def main():
    '''
    主函数：遍历处理当前目录下的REFINED文件并进行归纳
    '''
    # 检查配置
    if API_KEY == 'your-api-key-here':
        print('错误：请在脚本顶部填写您的API密钥')
        return
    
    print(f'=== 使用配置 ===')
    print(f'API地址: {API_BASE}')
    print(f'模型: {MODEL_NAME}')
    print(f'温度: {TEMPERATURE}')
    print(f'Top-p: {TOP_P}')
    
    # 设置OpenAI客户端
    try:
        client = setup_openai_client()
        print('参数配置成功！\n')
    except Exception as e:
        print(f'配置参数失败：{e}')
        return
    
    # 获取当前目录下所有.refined文件
    refined_files = sorted([f for f in os.listdir('.') if f.endswith('.refined') and os.path.isfile(f)])
    if not refined_files:
        print('当前目录下没有找到REFINED文件')
        return
    
    print(f'找到 {len(refined_files)} 个REFINED文件，开始处理...')
    
    processed_count = 0
    for refined_file in refined_files:
        # 检查是否已存在同名.md文件
        md_file = os.path.splitext(refined_file)[0] + '.md'
        if os.path.exists(md_file):
            print(f'跳过 {refined_file}，已存在对应的 {md_file}')
            continue
        
        print(f'正在处理：{refined_file}')
        
        # 读取并清理REFINED文件内容
        content = process_refined_file(refined_file)
        if not content:
            print(f'✗ {refined_file} 处理失败，跳过')
            continue
        
        # 调用OpenAI进行归纳
        summary = summarize_content(client, content)
        if summary:
            # 保存归纳结果到同名.md文件
            save_summary_to_md(summary, md_file)
            print(f'✓ {refined_file} 归纳完成，保存到 {md_file}')
            processed_count += 1
            
            # 短暂延迟，避免API调用过于频繁
            time.sleep(1)
        else:
            print(f'✗ {refined_file} 归纳失败，跳过')
    
    print(f'\n🎉 处理完成！共处理 {processed_count} 个REFINED文件')
    print(f'剩余 {len(refined_files) - processed_count} 个文件未处理（可能已存在Markdown文件或处理失败）')


if __name__ == '__main__':
    main()
