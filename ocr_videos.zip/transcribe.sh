#!/usr/bin/env bash
set -euo pipefail

MODEL_DIR="/content/drive/MyDrive/model"
LANG="zh"
INITIAL_PROMPT="注意看 这是一段中文普通话"
DEVICE="auto"

shopt -s nullglob
for file in *.m4a; do
  base="${file%.*}"
  srt_file="${base}.srt"

  if [[ -e "$srt_file" ]]; then
    echo "跳过：$srt_file 已存在"
    continue
  fi

  echo "处理：$file -> $srt_file"
  whisper-ctranslate2 "$file" \
    --language "$LANG" \
    --initial_prompt "$INITIAL_PROMPT" \
    --device "$DEVICE" \
    --output_format srt \
    --model_directory "$MODEL_DIR" \
    --local_files_only True \
    --verbose False
done
