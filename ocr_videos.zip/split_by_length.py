import json, os

def read_and_clean_text(file_path):
    with open(file=file_path, mode='r', encoding='utf-8') as file:
        content = file.read()
    lines = content.split(sep='\n')
    cleaned_lines = []

    for line in lines:
        stripped_line = line.strip()
        if stripped_line:
            cleaned_lines.append(stripped_line)

    return cleaned_lines

def split_by_length(lines, chunk_size=5000):
    chunks = []
    current_chunk_lines = []
    current_length = 0
    chunk_number = 1

    for line in lines:
        line_length = len(line)

        if current_length + line_length > chunk_size and current_chunk_lines:
            chunk_content = '\n'.join(current_chunk_lines)
            chapter_name = f'第{chunk_number:04}段'
            chunk_dict = {'chapter': chapter_name, 'content': chunk_content}
            chunks.append(chunk_dict)
            current_chunk_lines = [line]
            current_length = line_length
            chunk_number += 1
        else:
            current_chunk_lines.append(line)
            current_length += line_length

    if current_chunk_lines:
        chunk_content = '\n'.join(current_chunk_lines)
        chapter_name = f'第{chunk_number:04}段'
        chunk_dict = {'chapter': chapter_name, 'content': chunk_content}
        chunks.append(chunk_dict)

    return chunks

def save_to_json(chunks, output_path):
    with open(file=output_path, mode='w', encoding='utf-8') as file:
        json.dump(obj=chunks, fp=file, ensure_ascii=False)

def process_split(input_file, chunk_size=5000):
    try:
        output_file = f'{os.path.splitext(os.path.basename(input_file))[0]}.json'
        if os.path.exists(output_file):
            print(f'跳过 {input_file}, 因为 {output_file} 已存在')
        else:
            print(f'正在处理: {input_file}')
            cleaned_lines = read_and_clean_text(input_file)
            total_chars = sum(len(line) for line in cleaned_lines)
            print(f'文本总字数: {total_chars}')
            print(f'按每段 {chunk_size} 字进行分割(保持行完整)...')

            chunks = split_by_length(cleaned_lines, chunk_size)
            save_to_json(chunks, output_file)

            print(f'分割完成! 共分为 {len(chunks)} 段')
            print(f'结果已保存到: {output_file}')
    except FileNotFoundError:
        print(f'错误: 找不到文件 {input_file}')
    except ValueError:
        print('错误: 请输入有效的数字作为分割字数')
    except Exception as e:
        print(f'处理过程中出现错误: {e}')

if __name__ == '__main__':
    story_files = sorted([f for f in os.listdir('.') if f.endswith('.story') and os.path.isfile(f)])
    if not story_files:
        print('当前目录下未找到任何 .story 文件')
    else:
        print(f'找到 {len(story_files)} 个 .story 文件')
        for story_file in story_files:
            process_split(input_file=story_file)
