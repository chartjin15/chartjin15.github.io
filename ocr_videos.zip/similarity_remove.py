import os
from difflib import SequenceMatcher

def calculate_similarity(line1, line2):
    return SequenceMatcher(None, line1, line2).ratio()

def remove_similar_lines(file_path):
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    output_refined = f'{file_name}.refined'
    if os.path.exists(output_refined):
        print(f'跳过 {file_path}，因为 {output_refined} 已存在')
        return

    with open(file=file_path, mode='r', encoding='utf-8') as file_obj:
        lines = [' '.join(line.strip().split(sep=',')[1:]) for line in file_obj.readlines()]

    while True:
        n = len(lines)
        if n < 2:
            break
        deleted = False
        for i in range(n - 1):
            if calculate_similarity(lines[i], lines[i+1]) > 0.5:
                del lines[i]
                deleted = True
                break
        if not deleted:
            break

    with open(file=output_refined, mode='w', encoding='utf-8') as file_obj:
        for line in lines:
            file_obj.write(f'{line}\n')

if __name__ == '__main__':
    txt_files = sorted([f for f in os.listdir('.') if f.endswith('.txt') and os.path.isfile(f)])
    if not txt_files:
        print('当前目录下未找到任何 .txt 文件')
    else:
        print(f'找到 {len(txt_files)} 个 .txt 文件')
        for txt_path in txt_files:
            print(f'处理文件: {txt_path}')
            remove_similar_lines(txt_path)
