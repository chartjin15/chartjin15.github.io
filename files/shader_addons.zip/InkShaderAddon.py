from pickle import OBJ
import bpy
from bpy.types import (Panel, Operator)
import colorsys
from bpy.props import FloatProperty


bl_info = {
    "name": "Ink Shader Material",
    "author": "Chris CAI",
    "version": (1, 0),
    "blender": (2, 93, 0),
    "location": "Properties > Material",
    "description": "Creates an Ink Shader material and applies it to the selected object",
    "category": "Material"
    }

strength_value = 0.0
global emission_node_reference


def create_ink_shader_material():
    global emission_node_reference

    if "Ink_Shader" in bpy.data.materials:
        material = bpy.data.materials["Ink_Shader"]
        return material
    
    material = bpy.data.materials.new(name="Ink_Shader")
    material.use_nodes = True
    nodes = material.node_tree.nodes
    nodes.clear()

    #Create Material output
    material_output_node = nodes.new(type='ShaderNodeOutputMaterial')
    material_output_node.location = (1800,0)

    # Create Mix Shader
    mix_shader_node = nodes.new(type='ShaderNodeMixShader')
    mix_shader_node.location = (1600, 0)


    # Create External Emission
    emission_node_external = nodes.new(type='ShaderNodeEmission')
    emission_node_external.location = (1500, -300)
    emission_node_external.inputs['Color'].default_value = (0, 0, 0, 1)
    emission_node_external.inputs['Strength'].default_value = 1.0 

    # Connect Mix Shader to Material Shader
    links = material.node_tree.links
    links.new(mix_shader_node.outputs['Shader'], material_output_node.inputs['Surface']) 
    links.new(emission_node_external.outputs['Emission'], mix_shader_node.inputs['Shader']) 

    #The following is the coloring of ink strokes on the material

    # Create Noise Texture
    noise_texture_node = nodes.new('ShaderNodeTexNoise')
    noise_texture_node.location = (-600, 200)
    noise_texture_node.inputs['Scale'].default_value = 5.0
    noise_texture_node.inputs['Detail'].default_value = 2.8
    noise_texture_node.inputs['Roughness'].default_value = 0.45
    noise_texture_node.inputs['Distortion'].default_value = 0.0

    # Create Bump
    bump_node = nodes.new('ShaderNodeBump')
    bump_node.location = (-400, 200)
    bump_node.inputs['Strength'].default_value = 0.058
    bump_node.inputs['Distance'].default_value = 1.0


    # Create Math Vector
    vector_add_node = nodes.new('ShaderNodeVectorMath')
    vector_add_node.location = (-200, 200)
    vector_add_node.operation = 'ADD'
    vector_add_node.inputs[1].default_value = (0.0, 0.0, 0.0)  # Vector input

    fresnel_node = nodes.new('ShaderNodeFresnel')
    fresnel_node.location = (0, 200)
    fresnel_node.inputs['IOR'].default_value = 1.45

    color_ramp_node_1 = nodes.new('ShaderNodeValToRGB')
    color_ramp_node_1.location = (200, 300)
    color_ramp_node_1.color_ramp.elements[0].position = 0.164
    color_ramp_node_1.color_ramp.elements[1].position = 0.173 

    color_ramp_node_2 = nodes.new('ShaderNodeValToRGB')
    color_ramp_node_2.location = (200, 100)
    color_ramp_node_2.color_ramp.elements[0].position = 0.091
    color_ramp_node_2.color_ramp.elements[1].position = 0.109  

    # Connect the nodes
    links = material.node_tree.links
    links.new(noise_texture_node.outputs['Fac'], bump_node.inputs['Height'])
    links.new(bump_node.outputs['Normal'], vector_add_node.inputs[0])
    links.new(vector_add_node.outputs['Vector'], fresnel_node.inputs['Normal'])
    links.new(fresnel_node.outputs['Fac'], color_ramp_node_1.inputs['Fac'])
    links.new(fresnel_node.outputs['Fac'], color_ramp_node_2.inputs['Fac'])
    links.new(color_ramp_node_1.outputs['Color'], mix_shader_node.inputs['Fac'])
    links.new(color_ramp_node_2.outputs['Color'], mix_shader_node.inputs[2])



    #The following is the material for filling the head with ink painting color

    # Create Texture Coordinate
    texture_coordinate_node = nodes.new(type='ShaderNodeTexCoord')
    texture_coordinate_node.location = (-500, -500)


    # Create Mapping 
    mapping_node = nodes.new(type='ShaderNodeMapping')
    mapping_node.vector_type = 'POINT'
    mapping_node.location = (-300, -500)


    # Create Separate XYZ
    separate_xyz_node = nodes.new(type='ShaderNodeSeparateXYZ')
    separate_xyz_node.location = (-100,  -500)

    # Create Color Ramp
    color_ramp_node_3 = nodes.new('ShaderNodeValToRGB')
    color_ramp_node_3.location = (100, -500)
    color_ramp_node_3.name = "Ink Shader Upper Color Size"
    color_ramp_node_3.color_ramp.elements[0].position = 0.045
    color_ramp_node_3.color_ramp.elements[1].position = 0.377 

    # Connect the nodes
    links = material.node_tree.links
    links.new(texture_coordinate_node.outputs['Normal'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], separate_xyz_node.inputs['Vector'])
    links.new(separate_xyz_node.outputs['Z'], color_ramp_node_3.inputs['Fac'])



    # The following is how to fill the upper part of the material with ink painting color

    # Create Texture Coordinate
    texture_coordinate_node_middle = nodes.new(type='ShaderNodeTexCoord')
    texture_coordinate_node_middle.location = (-1000, -1000)


    # Create Mapping 
    mapping_node_middle = nodes.new(type='ShaderNodeMapping')
    mapping_node_middle.vector_type = 'POINT'
    mapping_node_middle.location = (-800, -1000)


    # Create Separate XYZ
    separate_xyz_node_middle = nodes.new(type='ShaderNodeSeparateXYZ')
    separate_xyz_node_middle.location = (-600,  -1000)
    
    # Create Color Ramp
    color_ramp_node_middle = nodes.new('ShaderNodeValToRGB')
    color_ramp_node_middle.location = (-400, -1000)
    color_ramp_node_middle.name = "Upper Ink Color Degree"
    color_ramp_node_middle.color_ramp.elements[0].position = 0.700
    color_ramp_node_middle.color_ramp.elements[1].position = 0.945

    # Create Mix_1
    mix_node_middle = nodes.new(type='ShaderNodeMixRGB')
    mix_node_middle.location = (0, -1000)
    mix_node_middle.blend_type = 'MIX'
    mix_node_middle.use_clamp = True  
    mix_node_middle.name = 'Upper Part Color Node'
    mix_node_middle.inputs['Color1'].default_value = (1, 0, 0, 1)  # A input is red
    mix_node_middle.inputs['Color2'].default_value = (1, 1, 0, 1)  # B input is yellow

    # Create Mix_2
    mix_node_middle_2 = nodes.new(type='ShaderNodeMixRGB')
    mix_node_middle_2.location = (200, -1000)
    mix_node_middle_2.blend_type = 'MIX'
    mix_node_middle_2.use_clamp = True  
    mix_node_middle_2.name = 'Upper Part Color Brightness Node'
    mix_node_middle_2.inputs['Color1'].default_value = (0, 0, 0, 1)  # A input is default
    mix_node_middle_2.inputs['Color2'].default_value = (1, 1, 0, 1)  # B input is yellow

    # Create Emission
    emission_node_middle = nodes.new(type='ShaderNodeEmission')
    emission_node_middle.location = (400, -1000)
    emission_node_middle.name = 'Upper Part Color Emission'
    emission_node_middle.inputs['Strength'].default_value = bpy.context.scene.ink_shader_strength  # The emission intensity is 0, and a panel needs to be provided for users to change.

    # Connect the nodes
    links = material.node_tree.links
    links.new(texture_coordinate_node_middle.outputs['Generated'], mapping_node_middle.inputs['Vector'])
    links.new(mapping_node_middle.outputs['Vector'], separate_xyz_node_middle.inputs['Vector'])
    links.new(separate_xyz_node_middle.outputs['Z'], color_ramp_node_middle.inputs['Fac'])
    links.new(color_ramp_node_middle.outputs['Color'], mix_node_middle.inputs['Fac'])
    links.new(mix_node_middle.outputs['Color'], mix_node_middle_2.inputs['Color1'])
    links.new(mix_node_middle_2.outputs['Color'], emission_node_middle.inputs['Color'])



    #The following is the first layer of background color filling of the material with the color of the ink painting

    #Create Layer Weight
    layer_weight_node = nodes.new(type='ShaderNodeLayerWeight')
    layer_weight_node.location = (-1000, -1400)
    layer_weight_node.inputs['Blend'].default_value = 0.5

    # Create first Color Ramp
    color_ramp_node_bc = nodes.new(type='ShaderNodeValToRGB')
    color_ramp_node_bc.location = (-800, -1400)
    color_ramp_node_bc.color_ramp.elements[0].position = 0.0
    color_ramp_node_bc.color_ramp.elements[1].position = 0.264
    color_ramp_node_bc.name = "Ink Shader Inner Background Color Size"
    color_ramp_node_bc.color_ramp.elements[0].color = (1.0, 1.0, 1.0, 1.0)
    color_ramp_node_bc.color_ramp.elements[1].color = (0.0, 0.0, 0.0, 1.0)

    # Create ADD Operation
    add_node_bc = nodes.new(type='ShaderNodeMath')
    add_node_bc.location = (-400, -1400)
    add_node_bc.operation = 'ADD'

    # Create second Color Ramp
    color_ramp_node_bc2 = nodes.new(type='ShaderNodeValToRGB')
    color_ramp_node_bc2.location = (-200, -1400)
    color_ramp_node_bc2.name = "Ink Shader Outer Background Color Size"
    color_ramp_node_bc2.color_ramp.elements[0].position = 0.573
    color_ramp_node_bc2.color_ramp.elements[1].position = 1.0

    # Create Noise Texture
    noise_texture_node_bc = nodes.new(type='ShaderNodeTexNoise')
    noise_texture_node_bc.location = (-600, -1700)
    noise_texture_node_bc.inputs['Scale'].default_value = 5.0
    noise_texture_node_bc.inputs['Detail'].default_value = 5.7
    noise_texture_node_bc.inputs['Roughness'].default_value = 0.617
    noise_texture_node_bc.inputs['Distortion'].default_value = 0.0

    # Connect the nodes
    links = material.node_tree.links
    links.new(layer_weight_node.outputs['Facing'], color_ramp_node_bc.inputs['Fac'])
    links.new(color_ramp_node_bc.outputs['Color'], add_node_bc.inputs[0])
    links.new(noise_texture_node_bc.outputs['Fac'], add_node_bc.inputs[1])
    links.new(add_node_bc.outputs['Value'], color_ramp_node_bc2.inputs['Fac'])



    #The following is the second layer of background color filling of the material with the color of the ink painting

    # Create Noise Texture
    noise_texture_node_outerbc = nodes.new(type='ShaderNodeTexNoise')
    noise_texture_node_outerbc.location = (-1300, -2500)
    noise_texture_node_outerbc.inputs['Scale'].default_value = 5.0
    noise_texture_node_outerbc.inputs['Detail'].default_value = 5.0
    noise_texture_node_outerbc.inputs['Roughness'].default_value = 0.492
    noise_texture_node_outerbc.inputs['Lacunarity'].default_value = 0.0
    noise_texture_node_outerbc.inputs['Distortion'].default_value = 0.0


    # Create first Color Ramp
    color_ramp_node_outerbc_1 = nodes.new(type='ShaderNodeValToRGB')
    color_ramp_node_outerbc_1.location = (-1100, -2300)
    color_ramp_node_outerbc_1.name = "Ink Shader Outer Background Color"
    color_ramp_node_outerbc_1.color_ramp.elements[0].color = (0, 0, 0, 1)  
    color_ramp_node_outerbc_1.color_ramp.elements[0].position = 0.205
    hue = 0.0
    saturation = 0.0
    value = 0.254
    rgb = colorsys.hsv_to_rgb(hue, saturation, value)
    color_ramp_node_outerbc_1.color_ramp.elements[1].position = 1.0  
    color_ramp_node_outerbc_1.color_ramp.elements[1].color = (rgb[0], rgb[1], rgb[2], 1.0)  

    # Create second Color Ramp
    color_ramp_node_outerbc_2 = nodes.new(type='ShaderNodeValToRGB')
    color_ramp_node_outerbc_2.location = (-1100,  -2600)
    color_ramp_node_outerbc_2.name = ("Ink Shader Inner Background Color")
    color_ramp_node_outerbc_2.color_ramp.elements[0].position = 0.0
    color_ramp_node_outerbc_2.color_ramp.elements[1].position = 1.0

    # Connect the nodes
    links = material.node_tree.links
    links.new(noise_texture_node_outerbc.outputs['Fac'], color_ramp_node_outerbc_1.inputs['Fac'])
    links.new(noise_texture_node_outerbc.outputs['Fac'], color_ramp_node_outerbc_2.inputs['Fac'])


    # The following is the operation of merging the second layer and the second layer of base color to fill the ink painting color.

    # Create Mix Shader
    mix_shader_node_colorCombine = nodes.new(type='ShaderNodeMixShader')
    mix_shader_node_colorCombine.location = (900, -1200)


    # Create Emission
    emission_node_colorCombine = nodes.new(type='ShaderNodeEmission')
    emission_node_colorCombine.location =  (700, -1400)
    emission_node_colorCombine.inputs['Strength'].default_value = 1.0

    # Create Mix
    mix_node_colorCombine = nodes.new(type='ShaderNodeMixRGB')
    mix_node_colorCombine.location = (500, -1600)
    mix_node_colorCombine.blend_type = 'MIX'
    mix_node_colorCombine.use_clamp = True  
    # mix_node_colorCombine.inputs['Color1'].default_value = (0, 0, 0, 1)  
    # mix_node_colorCombine.inputs['Color2'].default_value = (1, 1, 0, 1)  # B input is yellow

    # Connect the nodes
    links = material.node_tree.links
    links.new(color_ramp_node_bc2.outputs['Color'], mix_node_colorCombine.inputs['Fac'])
    links.new(color_ramp_node_outerbc_1.outputs['Color'], mix_node_colorCombine.inputs['Color1'])
    links.new(color_ramp_node_outerbc_2.outputs['Color'], mix_node_colorCombine.inputs['Color2'])
    links.new(mix_node_colorCombine.outputs['Color'], emission_node_colorCombine.inputs['Color'])
    links.new(emission_node_colorCombine.outputs['Emission'], mix_shader_node_colorCombine.inputs[1])
    links.new(emission_node_middle.outputs['Emission'], mix_shader_node_colorCombine.inputs[2])
    links.new(color_ramp_node_3.outputs['Color'], mix_shader_node_colorCombine.inputs['Fac'])


    # The following is the operation of merging the upper layer color and the edge ink painting color

    # Create Emission
    emission_node_colorCombine_upAndEdge = nodes.new(type='ShaderNodeEmission')
    emission_node_colorCombine_upAndEdge.location =  (1100, -1400)
    emission_node_colorCombine_upAndEdge.inputs['Strength'].default_value = 1.0

    # Create Mix Shader
    mix_shader_node_colorCombine_upAndEdge = nodes.new(type='ShaderNodeMixShader')
    mix_shader_node_colorCombine_upAndEdge.location = (1400, -500)

    # Connect the nodes
    links = material.node_tree.links
    links.new(emission_node_colorCombine_upAndEdge.outputs['Emission'], mix_shader_node_colorCombine_upAndEdge.inputs[2])
    links.new(mix_shader_node_colorCombine.outputs['Shader'], mix_shader_node_colorCombine_upAndEdge.inputs[1])
    links.new(color_ramp_node_2.outputs['Color'], mix_shader_node_colorCombine_upAndEdge.inputs['Fac'])
    links.new(mix_shader_node_colorCombine_upAndEdge.outputs['Shader'],mix_shader_node.inputs[1])
    links.new(emission_node_external.outputs['Emission'],mix_shader_node.inputs[2])
    
    # return Material
    return material

    
class MATERIAL_OT_apply_ink_shader(bpy.types.Operator):
    
    bl_idname = "material.apply_ink_shader"
    bl_label = "Apply Ink Shader"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        obj = context.active_object
        if obj is None:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        mat =  bpy.data.materials.get("Ink_Shader")
        
        if not mat:
            mat = create_ink_shader_material()
      
        if obj.data.materials:
            if obj.data.materials[0] != mat:
                obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
        
        return {'FINISHED'}


class ButtonOperator(bpy.types.Operator):
    bl_label = "Ink Shader Generator Operator"
    bl_idname = "object.ink_shader_apply"
    bl_options = {'REGISTER', 'UNDO'}
    

    def execute(self, context):
        
        #global strength_value
        #create_ink_shader_material()
        
        obj = context.active_object
        if obj is None:
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}
        
        mat = bpy.data.materials.get("Ink_Shader")
        if not mat:
            mat = create_ink_shader_material()  
        else:
            mat = mat.copy() 
        
        new_mat = mat.copy()
        new_mat.use_fake_user = True  

  
        if obj.data.materials:
            obj.data.materials[0] = new_mat
        else:
            obj.data.materials.append(new_mat)
        
        return {'FINISHED'}
    
    
class NodeColorOperator(bpy.types.Operator):
    """Tooltip for Node Color Operator"""
    bl_idname = "node.change_color"
    bl_label = "Change Node Color"

    color: bpy.props.FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        description="Change the color of the mix node"
    )

    def execute(self, context):
        mat = context.object.active_material
        if mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == 'MIX_RGB':
                    node.inputs['Color1'].default_value = self.color
                    
        return {'FINISHED'}
    


class InkShaderGeneratorPanel(bpy.types.Panel):
    bl_label = "Ink Shader Generator Panel"
    bl_idname = "OBJECT_PT_ink_shader_generator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "QuickTools"
    bl_label = "Ink Shader Generator"
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        layout.prop(context.scene, 'ink_shader_strength', text="Emission Strength")
        layout.prop(context.scene, 'ink_shader_color_1', text="Upper Ink Color 1")
        layout.prop(context.scene, 'ink_shader_color_2', text="Upper Ink Color 2")
        layout.prop(context.scene, 'ink_shader_color_3', text="Upper Ink Color Brightness")
        layout.prop(context.scene, 'ink_shader_upper_color_ramp_start', text="Upper Color Ramp Start")
        layout.prop(context.scene, 'ink_shader_upper_color_ramp_end', text="Upper Color Ramp End")
        layout.prop(context.scene, 'ink_shader_upper_color_size_ramp_start', text="Upper Color Size Ramp Start")
        layout.prop(context.scene, 'ink_shader_upper_color_size_ramp_end', text="Upper Color Size Ramp End")
        
        layout.prop(context.scene, 'ink_shader_inner_background_color_size_ramp_start', text="Inner Background Color Size Ramp Start")
        layout.prop(context.scene, 'ink_shader_inner_background_color_size_ramp_end', text="Inner Background Color Size Ramp End")
        
        layout.prop(context.scene, 'ink_shader_outer_background_color_size_ramp_start', text="Outer Background Color Size Ramp Start")
        layout.prop(context.scene, 'ink_shader_outer_background_color_size_ramp_end', text="Outer Background Color Size Ramp End")

        layout.prop(context.scene, 'ink_shader_outer_background_color_end', text="Outer Background Color")
        layout.prop(context.scene, 'ink_shader_inner_background_color_end', text="Inner Background Color")

        
        
        row.operator(ButtonOperator.bl_idname, text="Apply Ink Shader", icon="SPHERE")
        

def update_ink_color_value_1(self, context):
    
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]  
        if mat:
            nodes = mat.node_tree.nodes
            ink_color_node = nodes.get('Upper Part Color Node')
            if ink_color_node:
                ink_color_node.inputs['Color1'].default_value = context.scene.ink_shader_color_1
                print(f"Updated Upper Ink Color for {obj.name}")
            else:
                print("Emission node not found in the material.")
        else:
            print("Active material does not use nodes or is not found.")
    else:
        print("No active object or material to update.")


def update_ink_color_value_2(self, context):
    
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]  
        if mat:
            nodes = mat.node_tree.nodes
            ink_color_node = nodes.get('Upper Part Color Node')
            if ink_color_node:
                ink_color_node.inputs['Color2'].default_value = context.scene.ink_shader_color_2
                print(f"Updated Upper Ink Color for {obj.name}")
            else:
                print("Emission node not found in the material.")
        else:
            print("Active material does not use nodes or is not found.")
    else:
        print("No active object or material to update.")


def update_ink_color_value_3(self, context):
    
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]  
        if mat:
            nodes = mat.node_tree.nodes
            ink_color_node = nodes.get('Upper Part Color Brightness Node')
            if ink_color_node:
                ink_color_node.inputs['Color2'].default_value = context.scene.ink_shader_color_3
                print(f"Updated Upper Ink Color for {obj.name}")
            else:
                print("Emission node not found in the material.")
        else:
            print("Active material does not use nodes or is not found.")
    else:
        print("No active object or material to update.")
    
        
def update_strength_value(self, context):
    global strength_value
    strength_value = self.ink_shader_strength
    
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]  
        if mat:
            nodes = mat.node_tree.nodes
            emission_node = nodes.get('Upper Part Color Emission')
            if emission_node:
                emission_node.inputs['Strength'].default_value = self.ink_shader_strength
                print(f"Updated Emission Strength to {self.ink_shader_strength} for {obj.name}")
                context.view_layer.update()
            else:
                print("Emission node not found")
        else:
            print("Material not found")
    else:
        print("No material to update")



def update_color_ramp_start(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Upper Ink Color Degree")
            if cr_node:
                cr_node.color_ramp.elements[0].position = context.scene.ink_shader_upper_color_ramp_start
                print("Updated Color Ramp start position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")


def update_color_ramp_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Upper Ink Color Degree")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_upper_color_ramp_end
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")


def update_color_size_ramp_start(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Upper Color Size")
            if cr_node:
                cr_node.color_ramp.elements[0].position = context.scene.ink_shader_upper_color_size_ramp_start
                print("Updated Color Ramp start position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")


def update_color_size_ramp_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Upper Color Size")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_upper_color_size_ramp_end
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")
    
            

def update_inner_background_color_size_ramp_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Inner Background Color Size")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_inner_background_color_size_ramp_end
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")

def update_inner_background_color_size_ramp_start(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Inner Background Color Size")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_inner_background_color_size_ramp_start
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")

def update_outer_background_color_size_ramp_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Outer Background Color Size")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_outer_background_color_size_ramp_end
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")

def update_outer_background_color_size_ramp_start(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Outer Background Color Size")
            if cr_node:
                cr_node.color_ramp.elements[1].position = context.scene.ink_shader_outer_background_color_size_ramp_start
                print("Updated Color Ramp end position")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")

       


def register():
    bpy.utils.register_class(InkShaderGeneratorPanel)
    bpy.utils.register_class(ButtonOperator)
  
    bpy.types.Scene.ink_shader_strength = FloatProperty(
        name="Strength",
        description="Adjust the strength of the ink shader emission",
        default=1.0,
        min=0.0,
        max=10.0,
        update= update_strength_value
    )

    bpy.types.Scene.ink_shader_color_1 = bpy.props.FloatVectorProperty(
        name="Ink Shader Color",
        subtype='COLOR',
        size=4,
        default=(1.0, 0, 0, 1.0),
        min=0.0,
        max=1.0,
        description="Change the color of the Upper Ink Color 1",
        update=update_ink_color_value_1
    )
    
    bpy.types.Scene.ink_shader_color_3 = bpy.props.FloatVectorProperty(
        name="Ink Shader Color",
        subtype='COLOR',
        size=4,
        default=(1, 1, 0, 1),
        min=0.0,
        max=1.0,
        description="Change the color of the Upper Ink Color Brightness",
        update=update_ink_color_value_3
    )
    
    bpy.types.Scene.ink_shader_color_2 = bpy.props.FloatVectorProperty(
        name="Ink Shader Color",
        subtype='COLOR',
        size=4,
        default=(1, 1, 0, 1),
        min=0.0,
        max=1.0,
        description="Change the color of the Upper Ink Color 2",
        update=update_ink_color_value_2
    )
    
    bpy.types.Scene.ink_shader_upper_color_ramp_start = bpy.props.FloatProperty(
        name="Start Position",
        description="Start position of the color ramp",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_color_ramp_start
    )
    
    bpy.types.Scene.ink_shader_upper_color_ramp_end = bpy.props.FloatProperty(
        name="End Position",
        description="End position of the color ramp",
        default=1.0,
        min=0.0,
        max=1.0,
        update=update_color_ramp_end
    )
    
    bpy.types.Scene.ink_shader_upper_color_size_ramp_start = bpy.props.FloatProperty(
        name="Start Position",
        description="Start position of the color ramp",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_color_size_ramp_start
    )
    
    bpy.types.Scene.ink_shader_upper_color_size_ramp_end = bpy.props.FloatProperty(
        name="End Position",
        description="End position of the color ramp",
        default=1.0,
        min=0.0,
        max=1.0,
        update=update_color_size_ramp_end
    )
    
    bpy.types.Scene.ink_shader_inner_background_color_size_ramp_start = bpy.props.FloatProperty(
        name="Start Position",
        description="Start position of the color ramp",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_inner_background_color_size_ramp_start
    )
    
    bpy.types.Scene.ink_shader_inner_background_color_size_ramp_end = bpy.props.FloatProperty(
        name="End Position",
        description="End position of the color ramp",
        default=1.0,
        min=0.0,
        max=1.0,
        update=update_inner_background_color_size_ramp_end
    )
    
    bpy.types.Scene.ink_shader_outer_background_color_size_ramp_start = bpy.props.FloatProperty(
        name="Start Position",
        description="Start position of the color ramp",
        default=0.0,
        min=0.0,
        max=1.0,
        update=update_outer_background_color_size_ramp_start
    )
    
    bpy.types.Scene.ink_shader_outer_background_color_size_ramp_end = bpy.props.FloatProperty(
        name="End Position",
        description="End position of the color ramp",
        default=1.0,
        min=0.0,
        max=1.0,
        update=update_outer_background_color_size_ramp_end
       
    )
    
    bpy.types.Scene.ink_shader_outer_background_color_end = bpy.props.FloatVectorProperty(
        name="End Color",
        description="Color of the end position of the color ramp",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,  # RGBA
        update=update_outer_background_color_end
    )
    
    bpy.types.Scene.ink_shader_inner_background_color_end = bpy.props.FloatVectorProperty(
        name="End Color",
        description="Color of the end position of the color ramp",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=4,  # RGBA
        update=update_inner_background_color_end
    )
    

def update_outer_background_color_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Outer Background Color")
            if cr_node:
       
                cr_node.color_ramp.elements[-1].color = context.scene.ink_shader_outer_background_color_end
                print("Updated Color Ramp end color")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")
    else:
        print("No active object or the active object does not have materials")


def update_inner_background_color_end(self, context):
    obj = context.active_object
    if obj and obj.data.materials:
        mat = obj.data.materials[0]
        if mat.use_nodes:
            nodes = mat.node_tree.nodes
            cr_node = nodes.get("Ink Shader Inner Background Color")
            if cr_node:
          
                cr_node.color_ramp.elements[-1].color = context.scene.ink_shader_inner_background_color_end
                print("Updated Color Ramp end color")
            else:
                print("No Color Ramp node found")
        else:
            print("Material does not use nodes")
    else:
        print("No active object or the active object does not have materials")



def unregister():
    bpy.utils.unregister_class(InkShaderGeneratorPanel)
    bpy.utils.unregister_class(ButtonOperator)
    del bpy.types.Scene.ink_shader_strength
    del bpy.types.Scene.ink_shader_color_1
    del bpy.types.Scene.ink_shader_color_2
    del bpy.types.Scene.ink_shader_color_3
    
    del bpy.types.Scene.ink_shader_upper_color_ramp_start
    del bpy.types.Scene.ink_shader_upper_color_ramp_end
    
    del bpy.types.Scene.ink_shader_upper_color_size_ramp_start
    del bpy.types.Scene.ink_shader_upper_color_size_ramp_end
    
    del bpy.types.Scene.ink_shader_inner_background_color_size_ramp_start
    del bpy.types.Scene.ink_shader_inner_background_color_size_ramp_end
    
    del bpy.types.Scene.ink_shader_outer_background_color_size_ramp_start
    del bpy.types.Scene.ink_shader_outer_background_color_size_ramp_end
    del bpy.types.Scene.ink_shader_outer_background_color_end
    del bpy.types.Scene.ink_shader_inner_background_color_end



if __name__ == "__main__":
    register()






